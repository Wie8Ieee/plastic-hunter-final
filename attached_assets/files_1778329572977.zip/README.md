# 🌊 Plastic Hunter AI — Marine Pollution Detection System

**AESS Sustainability Hackathon 2026**
Track 11 — Sustainable Sonar Systems for Marine & Climate Protection

---

## Project Overview

Plastic Hunter AI is an AI-powered system that analyzes marine images to automatically detect plastic pollution using Computer Vision. It identifies polluted areas, draws bounding boxes around detected items, and generates interactive maps showing pollution locations.

**SDGs Addressed:** SDG 14 (Life Below Water) · SDG 13 (Climate Action) · SDG 12 (Responsible Consumption)

---

## System Architecture

```
Image Upload → FastAPI Backend → Detection Model (YOLOv8-simulated)
     → SQLite Storage → Leaflet.js Map + Chart.js Dashboard
```

---

## How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Start the server
```bash
python main.py
```
Or:
```bash
uvicorn main:app --host 0.0.0.0 --port 8080 --reload
```

### 3. Open the app
Visit: `http://localhost:8080`

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/` | Frontend application |
| `POST` | `/detect` | Upload image, get detection results |
| `POST` | `/demo` | Load sample detection data |
| `GET` | `/results` | All past detections from DB |
| `GET` | `/stats` | Summary statistics + baseline comparison |

---

## Key Results (Simulated)

- Detection covers 8 plastic types: bottles, bags, nets, fragments, foam, caps, straws, film
- Bounding box output with confidence scores (0–1)
- Severity classification: None / Low / Medium / High
- Baseline vs Optimized: estimated ~28% reduction in undetected plastic events

---

## Repository Structure

```
/
├── main.py          # FastAPI app + routes
├── detector.py      # Detection logic (simulated YOLOv8)
├── database.py      # SQLite operations
├── static/
│   └── index.html   # Complete frontend (upload, map, stats, about)
├── requirements.txt
└── README.md
```

---

## Assumptions & Limitations

- Detection is **simulated** — replace `detector.py` with real YOLOv8 inference trained on TACO or PlasticLitter dataset for production
- GPS coordinates are approximated for demo purposes
- Confidence scores reflect model certainty, not ground truth
- Results depend on image quality and lighting conditions

---

## Future Improvements

- Train YOLOv8 on real marine plastic dataset (TACO, PlasticLitter)
- Add video frame-by-frame processing
- Integrate GPS metadata from drone/satellite imagery
- Deploy on cloud with persistent storage
- Add real-time alerting for high-severity detections

---

## AI Usage Disclosure

This project used AI assistance (Claude) for:
- Code structure and FastAPI boilerplate generation
- Frontend HTML/CSS/JS scaffold
- Documentation drafting

All outputs were reviewed, validated, and adapted by the team. The detection simulation logic was designed by the team to match real YOLOv8 output format.

---

*Plastic Hunter AI — AESS Sustainability Hackathon 2026*
